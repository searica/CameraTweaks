<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">1.4.0</td>
			<td align="left">
				<ul>
					<li>Updated for Deep North release!</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.3.1</td>
			<td align="left">
				<ul>
					<li>Max camera distance now applies whenever you are attached to a boat via sitting or holding fast.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.3.0</td>
			<td align="left">
				<ul>
					<li>Updated for Bog Witch update.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.2.0</td>
			<td align="left">
				<ul>
					<li>Updated for Ashlands release.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.1.2</td>
			<td align="left">
				<ul>
					<li>Added option to lock the direction your character faces to always be the same as the camera direction.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.1.1</td>
			<td align="left">
				<ul>
					<li>Fixed bug where FoV would only update if config was changed in-game.</li>
					<li>Minor performance optimizations.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.1.0</td>
			<td align="left">
				<ul>
					<li>Added setting to control FoV</li>
					<li>Minor optimizations to filewatcher.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.3/1.0.4</td>
			<td align="left">
				<ul>
					<li>Fixed issue with camera settings sometimes not updating right away due to triggering on LateUpdate.</li>
					<li>Changed icon.</li>
					<li>Fixed README.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.0 - 1.0.2</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>
